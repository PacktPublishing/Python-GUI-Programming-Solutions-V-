'''
Created on Oct 24, 2015
Chapter 10
@author: Burkhard
'''


import wx                  
from wx import glcanvas
from OpenGL.GL import *
from OpenGL.GLUT import *

