'''
Created on Jun 21, 2015
Ch03
@author: Burkhard
'''
### SCREENSHOT 8 ##############################
from tkinter import messagebox as mBox
from tkinter import Tk
root = Tk()
root.withdraw()
mBox.showinfo('This is a Title', 'A Python GUI created using tkinter:\nThe year is 2015')



